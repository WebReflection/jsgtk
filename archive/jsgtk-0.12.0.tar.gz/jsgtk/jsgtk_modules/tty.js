module.exports = {
  isatty: function () {
    return true;
  }
};