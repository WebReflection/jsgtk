/* jshint esversion: 6, strict: true, node: true */(function (e) {"use strict";exports.JSGTK=true;exports.VERSION="v0.9.11";}(this));
