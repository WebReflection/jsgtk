module.exports = {
  createUnzip: function () {
    return true;
  }
};