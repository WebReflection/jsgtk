module.exports = {
  isatty: ()=>true
}