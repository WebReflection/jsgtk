/*jshint esversion:6,strict:true,node:true*/(function (e) {"use strict";e.JSGTK=true;e.VERSION="v0.9.11";}(this));
