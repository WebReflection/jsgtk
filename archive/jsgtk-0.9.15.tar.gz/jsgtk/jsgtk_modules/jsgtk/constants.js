/*jshint esversion:6,strict:true,node:true*/(function (e) {'use strict';e.JSGTK=true;e.VERSION='0.9.15';}(this));
